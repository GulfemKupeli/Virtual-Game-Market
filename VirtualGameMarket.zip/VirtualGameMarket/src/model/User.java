package model;

import java.util.ArrayList;
import java.util.List;
import data.Node;

public class User {
    private String username;
    private String passwordHash;
    private boolean isAdmin;
    private List<Integer> purchaseHistory;
    private List<Integer> shoppingList;
    private List<Node> orderHistory = new ArrayList<>();

    public User(String username, String passwordHash, boolean isAdmin) {
        this.username = username;
        this.passwordHash = passwordHash;
        this.isAdmin = isAdmin;
        this.purchaseHistory = new ArrayList<>();
        this.shoppingList = new ArrayList<>();
    }
    public List<Node> getOrderHistory() {
        return orderHistory;
    }

    public String getUsername() {
        return username;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public boolean isAdmin() {
        return isAdmin;
    }

    @Override
    public String toString() {
        return "User{" +
                "username='" + username + '\'' +
                ", isAdmin=" + isAdmin +
                '}';
    }
}
