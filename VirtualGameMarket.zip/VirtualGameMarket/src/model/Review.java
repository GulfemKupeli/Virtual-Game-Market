package model;

public class Review {
    private String username;
    private String comment;
    private int rating;
    private int id;
    private int gameId;
    public static int nextId =1;


    public Review(String username, String comment, int rating, int gameId) {
        this.username = username;
        this.comment = comment;
        this.rating = rating;
        this.gameId = this.gameId;
        this.id = nextId++;
    }

    public String getUsername() {
        return username;
    }

    public String getComment() {
        return comment;
    }

    public int getRating() {
        return rating;
    }
    public int getId() {
        return id;
    }
    public int getGameId() {
        return gameId;
    }
    public void setId(int id) {
        this.id = id;
    }



    @Override
    public String toString() {
        return String.format("User: %s\nRating: %d/5\nComment: %s", username, rating, comment);
    }
}
