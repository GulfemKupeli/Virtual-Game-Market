package model;

import data.Node;

import java.util.ArrayList;
import java.util.List;

public class ShoppingCart {
    private List<Node> items;

    public ShoppingCart() {
        items = new ArrayList<>();
    }

    public void addItem(Node item) {
        items.add(item);
    }

    public void removeItem(Node item) {
        items.remove(item);
    }

    public List<Node> getItems() {
        return items;
    }

    public double getTotalPrice() {
        double totalPrice = 0;
        for (Node item : items) {
            totalPrice += item.price;
        }
        return totalPrice;
    }
}
