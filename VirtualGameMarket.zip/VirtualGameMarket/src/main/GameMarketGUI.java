package main;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.List;

import data.Node;
import data.BST;
import data.HashTable;
import model.User;
import views.UserRegistrationDialog;
import views.AddGameDialog;
import views.LoginDialog;
//import com.formdev.flatlaf.FlatDarkLaf;
import model.Review;
import model.ShoppingCart;

public class GameMarketGUI extends JFrame {
    private JList<String> cartList;
    private DefaultListModel<String> cartListModel;
    private JTextArea cartTotalArea;
    private Map<Integer, BST> genreTrees;
    private HashTable hashTable;
    private PriorityQueue<Node> minHeap;
    private JList<String> gameList;
    private DefaultListModel<String> gameListModel;
    private JTextField searchField;
    private JComboBox<String> genreComboBox;
    private JTextArea outputArea;
    private List<String> lines;
    private User currentUser = null;
    private ShoppingCart shoppingCart = new ShoppingCart();
    List<Node> allNodes = new ArrayList<>();
    private Map<Integer, List<Review>> gameReviews = new HashMap<>();
    private Map<Integer, PriorityQueue<Node>> genreHeaps;
    private Map<User, ShoppingCart> userCarts = new HashMap<>();
    private Map<Integer, Node> gameMap = new HashMap<>();
    private JPanel reviewsPanel;
    private JTextField priceField;
    private JTextField stockField;
    private Map<Integer, Integer> gamesSold = new HashMap<>();
    private Map<Integer, Double> gameCosts = new HashMap<>();
    private JDialog gameDetailsDialog;
    private static HashMap<String, User> registeredUsers = new HashMap<>();
    private final String[] genres = {"All Genres", "RPG", "Sports/Racing", "Sandbox & Simulation", "Nintendo Switch Exclusives", "Japanese RPGs (JRPGs)", "Fighting Games", "First-Person Shooters (FPS)", "Strategy Games"};

    public GameMarketGUI() {
        super("Virtual Game Market");

        setSize(1000, 800);
        setLayout(new BorderLayout());
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        loadUserData();

        outputArea = new JTextArea(20, 50);
        outputArea.setEditable(false);
        JScrollPane outputScrollPane = new JScrollPane(outputArea);
        add(outputScrollPane, BorderLayout.SOUTH);

        JPanel searchPanel = new JPanel(new FlowLayout());
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        genreComboBox = new JComboBox<>(genres);
        searchPanel.add(searchField);
        searchPanel.add(genreComboBox);
        searchPanel.add(searchButton);
        add(searchPanel, BorderLayout.NORTH);

        JPanel cartPanel = new JPanel(new BorderLayout());
        cartPanel.add(new JLabel("Shopping Chart"), BorderLayout.NORTH);
        cartListModel = new DefaultListModel<>();
        cartList = new JList<>(cartListModel);
        JScrollPane cartScrollPane = new JScrollPane(cartList);
        cartPanel.add(cartScrollPane, BorderLayout.CENTER);
        cartTotalArea = new JTextArea(1, 10);
        cartTotalArea.setEditable(false);
        cartPanel.add(cartTotalArea, BorderLayout.SOUTH);
        add(cartPanel, BorderLayout.EAST);

        JButton registerButton = new JButton("Register");
        JButton loginButton = new JButton("Login");
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(registerButton);
        buttonPanel.add(loginButton);
        add(buttonPanel, BorderLayout.EAST);
        JButton viewCartButton = new JButton("View Cart");
        buttonPanel.add(viewCartButton);
        viewCartButton.addActionListener(e -> {
            if (currentUser != null) {
                ShoppingCart userCart = userCarts.get(currentUser);
                if (userCart != null && !userCart.getItems().isEmpty()) {
                    JDialog cartDialog = new JDialog(GameMarketGUI.this, "Shopping Cart", true);
                    cartDialog.setLayout(new BorderLayout());
                    cartDialog.setSize(400, 300);

                    DefaultListModel<String> cartItemsModel = new DefaultListModel<>();
                    JList<String> cartItemsList = new JList<>(cartItemsModel);
                    for (Node game : userCart.getItems()) {
                        cartItemsModel.addElement(game.toString());
                    }

                    JLabel cartTotalLabel = new JLabel("Total: $" + String.format("%.2f", userCart.getTotalPrice()));

                    JPanel cartDialogButtonPanel = new JPanel(new FlowLayout());

                    JButton removeItemButton = new JButton("Remove Item");
                    removeItemButton.addActionListener(removeEvent -> {
                        int selectedIndex = cartItemsList.getSelectedIndex();
                        if (selectedIndex != -1) {
                            Node removedGame = userCart.getItems().remove(selectedIndex);
                            cartItemsModel.removeElementAt(selectedIndex);
                            cartTotalLabel.setText("Total: $" + String.format("%.2f", userCart.getTotalPrice())); // Toplam fiyatı güncelle
                            updateCartDisplay();

                            if (gameDetailsDialog != null && gameDetailsDialog.isVisible()) {
                                showGameDetails(removedGame.toString());
                            }
                        }
                    });
                    cartDialogButtonPanel.add(removeItemButton);

                    JButton checkoutButton = new JButton("Checkout");
                    checkoutButton.addActionListener(checkoutEvent -> {
                        cartDialog.dispose();
                        checkout();
                    });
                    cartDialogButtonPanel.add(checkoutButton);

                    cartDialog.add(new JScrollPane(cartItemsList), BorderLayout.CENTER);
                    cartDialog.add(cartTotalLabel, BorderLayout.NORTH);
                    cartDialog.add(cartDialogButtonPanel, BorderLayout.SOUTH);

                    cartDialog.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(this, "Your cart is empty!");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Please log in to view your cart.");
            }
        });
        JButton purchaseCheapestButton = new JButton("Purchase Cheapest Games");
        purchaseCheapestButton.addActionListener(e -> checkoutCheapestGames());
        buttonPanel.add(purchaseCheapestButton);


        JButton orderHistoryButton = new JButton("Order History");
        orderHistoryButton.addActionListener(e -> showOrderHistory());
        buttonPanel.add(orderHistoryButton);

        JButton reportButton = new JButton("Financial Report");
        reportButton.addActionListener(e -> showFinancialReport());
        buttonPanel.add(reportButton);

        gameListModel = new DefaultListModel<>();
        gameList = new JList<>(gameListModel);
        JScrollPane scrollPane = new JScrollPane(gameList);
        add(scrollPane, BorderLayout.CENTER);

        loadData();
        loadReviews();
        displayLoadedData();
        updateCartDisplay();

        searchButton.addActionListener(e -> searchGames());
        registerButton.addActionListener(e -> {
            UserRegistrationDialog dialog = new UserRegistrationDialog(GameMarketGUI.this);
            dialog.setVisible(true);
        });
        loginButton.addActionListener(e -> {
            LoginDialog dialog = new LoginDialog(GameMarketGUI.this);
            dialog.setVisible(true);
        });
        JButton addGameButton = new JButton("Add Game");
        addGameButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (currentUser != null && currentUser.isAdmin()) {
                    AddGameDialog dialog = new AddGameDialog(GameMarketGUI.this);
                    dialog.setVisible(true);
                } else {
                    JOptionPane.showMessageDialog(GameMarketGUI.this, "Only admins can add games.");
                }
            }
        });
        buttonPanel.add(addGameButton);

        List<Node> nodes = new ArrayList<>();
        for (BST tree : genreTrees.values()) {
            addGamesToList(tree.root, nodes);
        }

        gameList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    int index = gameList.locationToIndex(e.getPoint());
                    if (index != -1) {
                        String selectedGame = gameListModel.getElementAt(index);
                        showGameDetails(selectedGame);
                    }
                }
            }
        });

        saveUserData();
        populateGameList(new ArrayList<>(minHeap));
        setVisible(true);
    }
    private void checkoutCheapestGames() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this, "Please log in to purchase games.");
            return;
        }

        String[] options = genres;
        int selectedGenreIndex = JOptionPane.showOptionDialog(this,
                "Select a category to purchase cheapest items:",
                "Category Selection",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null, options, options[0]);
        if (selectedGenreIndex == JOptionPane.CLOSED_OPTION) {
            return;
        }

        String selectedGenre = options[selectedGenreIndex];
        int genreId = selectedGenre.equals("All Genres") ? -1 : selectedGenreIndex + 1;

        int quantity = getQuantityFromUser();
        if (quantity <= 0) {
            return;
        }

        List<Node> cheapestGames = new ArrayList<>();
        BST relevantTree = genreId == -1 ? null : genreTrees.get(genreId);

        if (relevantTree != null) {
            findCheapestGamesInBST(relevantTree.root, cheapestGames, quantity);
        } else {
            for (BST tree : genreTrees.values()) {
                findCheapestGamesInBST(tree.root, cheapestGames, quantity);
            }
            cheapestGames.sort(Comparator.comparingDouble(Node::getPrice));
            cheapestGames = cheapestGames.subList(0, Math.min(quantity, cheapestGames.size()));
        }

        if (cheapestGames.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No games in stock for the selected category.");
            return;
        }

        double totalPrice = cheapestGames.stream().mapToDouble(Node::getPrice).sum();

        int confirm = JOptionPane.showConfirmDialog(this,
                String.format("Total price: $%.2f\nConfirm purchase?", totalPrice),
                "Confirm Checkout",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            for (Node game : cheapestGames) {
                game.stock--;
                gamesSold.put(game.gameId, gamesSold.getOrDefault(game.gameId, 0) + 1);
                updateMarketDataFile(game);
                currentUser.getOrderHistory().add(game);
                saveUserOrderHistory(currentUser);

             //avl dengelemek için
                genreTrees.get(game.genreId).delete(game);
                genreTrees.get(game.genreId).insert(game);
            }
            JOptionPane.showMessageDialog(this, "Purchase completed!");
            updateCartDisplay();
            saveUserData();
        }
    }
    private void findCheapestGamesInBST(Node node, List<Node> cheapestGames, int quantity) {
        if (node == null || cheapestGames.size() >= quantity) {
            return;
        }

        findCheapestGamesInBST(node.left, cheapestGames, quantity);

        if (node.stock > 0 && cheapestGames.size() < quantity) {
            cheapestGames.add(node);
        }
        findCheapestGamesInBST(node.right, cheapestGames, quantity);
    }

    private void showFinancialReport() {
        double revenue = calculateTotalRevenue();
        double expenses = calculateTotalExpenses();
        double profit = calculateProfit();
        String report = String.format(
                "Financial Report:\nTotal Revenue: $%.2f\nTotal Expenses: $%.2f",
                revenue, expenses, profit
        );
        JOptionPane.showMessageDialog(this, report);
    }
    private void showOrderHistory() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(this, "Please log in to view your order history.");
            return;
        }

        List<Node> orderHistory = currentUser.getOrderHistory();
        if (orderHistory.isEmpty()) {
            JOptionPane.showMessageDialog(this, "You have no previous orders.");
            return;
        }

        StringBuilder historyText = new StringBuilder("Your Order History:\n");
        for (Node game : orderHistory) {
            historyText.append(game.toString()).append("\n");
        }

        JOptionPane.showMessageDialog(this, historyText.toString());
    }
    private void saveUserOrderHistory(User user) {
        String filename = user.getUsername() + "_order_history.dat";
        try (PrintWriter writer = new PrintWriter(filename)) {
            for (Node game : user.getOrderHistory()) {
                writer.println(game.gameId);
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving order history.");
        }
    }
    public boolean registerUser(User newUser) {
        if (registeredUsers.containsKey(newUser.getUsername())) {
            return false;
        } else {
            registeredUsers.put(newUser.getUsername(), newUser);
            saveUserData();
            return true;
        }
    }
    private void showGameDetails(String selectedGame) {
        String[] gameInfo = selectedGame.split(",");
        int gameId = Integer.parseInt(gameInfo[0].trim());

        Node gameNode = gameMap.get(gameId);
        if (gameNode == null) {
            JOptionPane.showMessageDialog(this, "Game not found.");
            return;
        }
        JDialog gameDetailsDialog = new JDialog(this, gameNode.name, true);
        gameDetailsDialog.setLayout(new BorderLayout());
        gameDetailsDialog.setSize(600, 500);
        gameDetailsDialog.setLocationRelativeTo(null);
        this.gameDetailsDialog = gameDetailsDialog;

        JPanel contentPanel = new JPanel(new BorderLayout());

        JPanel infoPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        int row = 0;
        addLabelAndValue(infoPanel, gbc, row++, "Game ID:", String.valueOf(gameNode.gameId));
        addLabelAndValue(infoPanel, gbc, row++, "Name:", gameNode.name);


        gbc.gridx = 0;
        gbc.gridy = row;
        infoPanel.add(new JLabel("Genre:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        genreComboBox = new JComboBox<>(genres);
        genreComboBox.setSelectedIndex(gameNode.genreId - 1);
        genreComboBox.setEnabled(currentUser != null && currentUser.isAdmin());
        infoPanel.add(genreComboBox, gbc);
        row++;

        gbc.gridx = 0;
        gbc.gridy = row;
        infoPanel.add(new JLabel("Price:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        priceField = new JTextField();
        priceField.setText(String.format("%.2f", gameNode.price));
        priceField.setEnabled(currentUser != null && currentUser.isAdmin());
        infoPanel.add(priceField, gbc);
        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        infoPanel.add(new JLabel("Stock:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        stockField = new JTextField();
        stockField.setText(String.valueOf(gameNode.stock));
        stockField.setEnabled(currentUser != null && currentUser.isAdmin());
        infoPanel.add(stockField, gbc);
        row++;

//resim paneli
        JPanel imagePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel imageLabel = new JLabel();
        if (gameNode.imagePath != null && !gameNode.imagePath.isEmpty()) {
            try {
                ImageIcon imageIcon = new ImageIcon(new ImageIcon(gameNode.imagePath).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
                imageLabel.setIcon(imageIcon);
            } catch (Exception ex) {
                imageLabel.setText("Image not available");
                System.err.println("Error loading image: " + ex.getMessage());
            }
        } else {
            imageLabel.setText("No image available");
        }
        imageLabel.setPreferredSize(new Dimension(150, 150));
        imagePanel.add(imageLabel);

        contentPanel.add(infoPanel, BorderLayout.NORTH);
        contentPanel.add(imagePanel, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new FlowLayout());

        JButton addToCartButton = new JButton("Add to Cart");
        addToCartButton.addActionListener(e -> {
            if (gameNode.stock > 0) {
                shoppingCart.addItem(gameNode);
                updateCartDisplay();
                JOptionPane.showMessageDialog(gameDetailsDialog, "Game added to cart!");
            } else {
                JOptionPane.showMessageDialog(gameDetailsDialog, "Sorry, this game is out of stock!");
            }
        });
        buttonPanel.add(addToCartButton);
        //review butonu ekleme
        if (currentUser != null) {
            JButton addReviewButton = new JButton("Add Review");
            addReviewButton.addActionListener(e -> {
                String comment = JOptionPane.showInputDialog(gameDetailsDialog, "Enter your review:");
                if (comment != null && !comment.trim().isEmpty()) {
                    int rating = getRatingFromUser(gameDetailsDialog);
                    if (rating != -1) {
                        boolean reviewExists = gameReviews.getOrDefault(gameId, Collections.emptyList())
                                .stream()
                                .anyMatch(r -> r.getUsername().equals(currentUser.getUsername()));

                        if (!reviewExists) {
                            Review newReview = new Review(currentUser.getUsername(), comment, rating, gameId);
                            gameReviews.computeIfAbsent(gameId, k -> new ArrayList<>()).add(newReview);
                            addReviewToPanel(newReview);
                            saveReviews();
                            gameDetailsDialog.revalidate();
                        } else {
                            JOptionPane.showMessageDialog(gameDetailsDialog, "You already reviewed this game.");
                        }
                    }
                }
            });
            buttonPanel.add(addReviewButton);
        }
        if (currentUser != null && currentUser.isAdmin()) {
            JButton saveChangesButton = new JButton("Save Changes");
            saveChangesButton.addActionListener(e -> {
                try {
                    int newGenreId = genreComboBox.getSelectedIndex() + 1;
                    double newPrice = Double.parseDouble(priceField.getText());
                    int newStock = Integer.parseInt(stockField.getText());

                    gameNode.genreId = newGenreId;
                    gameNode.price = newPrice;
                    gameNode.stock = newStock;
                    updateGame(gameNode);
                    gameDetailsDialog.dispose();
                    showGameDetails(gameNode.toString());
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(gameDetailsDialog, "Invalid input format.");
                }
            });
            buttonPanel.add(saveChangesButton);
        }

        if (currentUser != null && currentUser.isAdmin()) {
            JButton updateImageButton = new JButton("Update Image");
            updateImageButton.addActionListener(e -> {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File("images"));
                int result = fileChooser.showOpenDialog(gameDetailsDialog);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();
                    String newImagePath = selectedFile.getAbsolutePath();
                    gameNode.imagePath = newImagePath;
                    updateMarketDataFile(gameNode);
                    try {
                        ImageIcon imageIcon = new ImageIcon(new ImageIcon(newImagePath).getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH));
                        imageLabel.setIcon(imageIcon);
                    } catch (Exception ex) {
                        imageLabel.setText("Image not available");
                        System.err.println("Error loading image: " + ex.getMessage());
                    }
                    JOptionPane.showMessageDialog(gameDetailsDialog, "Image updated successfully!");
                }
            });
            buttonPanel.add(updateImageButton);
        }//adminse deletegame kullanılıyor
        if (currentUser != null && currentUser.isAdmin()) {
            JButton deleteGameButton = new JButton("Delete Game");
            deleteGameButton.addActionListener(e -> {
                int confirm = JOptionPane.showConfirmDialog(
                        gameDetailsDialog,
                        "Are you sure you want to delete this game?",
                        "Confirm Deletion",
                        JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    deleteGame(gameId);
                    gameDetailsDialog.dispose();
                }
            });
            buttonPanel.add(deleteGameButton);
        }
        JPanel reviewsWrapperPanel = new JPanel(new BorderLayout());
        reviewsPanel = new JPanel();
        reviewsPanel.setLayout(new BoxLayout(reviewsPanel, BoxLayout.Y_AXIS));
        loadReviews();
        List<Review> gameReviewsList = gameReviews.getOrDefault(gameId, Collections.emptyList());
        for (Review review : gameReviewsList) {
            addReviewToPanel( review);
        }
        JScrollPane reviewsScrollPane = new JScrollPane(reviewsPanel);
        reviewsWrapperPanel.add(reviewsScrollPane, BorderLayout.CENTER);
        contentPanel.add(reviewsScrollPane, BorderLayout.SOUTH);
        gameDetailsDialog.add(contentPanel, BorderLayout.CENTER);
        gameDetailsDialog.add(buttonPanel, BorderLayout.SOUTH);
        gameDetailsDialog.setVisible(true);
    }
    public void updateGame(Node updatedNode) {
        Node deletedNode = gameMap.remove(updatedNode.gameId);
        if (deletedNode != null) {
            genreTrees.get(deletedNode.genreId).delete(deletedNode);
            hashTable.delete(deletedNode.name);
            genreHeaps.get(deletedNode.genreId).remove(deletedNode);
            minHeap.remove(deletedNode);
        }//market dosyasıı düzenliyor
        try (PrintWriter writer = new PrintWriter("Market.dat")) {
            for (Node node : gameMap.values()) {
                writer.println(node.toStringForFile(genres));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating Market.dat: " + e.getMessage());
            e.printStackTrace();
        }
        gameMap.put(updatedNode.gameId, updatedNode);
        genreTrees.computeIfAbsent(updatedNode.genreId, k -> new BST()).insert(updatedNode);
        hashTable.insert(updatedNode.name, updatedNode);
        genreHeaps.computeIfAbsent(updatedNode.genreId, k -> new PriorityQueue<>(Comparator.comparingDouble(Node::getPrice)))
                .offer(updatedNode);
        minHeap.offer(updatedNode);
        gameCosts.put(updatedNode.gameId,updatedNode.price);
        refreshGameList();
        displayLoadedData();
        JOptionPane.showMessageDialog(this, "Game updated successfully!");
    }
    private void addReviewToPanel(Review review) {
        JTextArea reviewArea = new JTextArea(review.toString());
        reviewArea.setEditable(false);
        reviewArea.setLineWrap(true);
        reviewArea.setWrapStyleWord(true);
        reviewsPanel.add(reviewArea);
        reviewsPanel.add(Box.createVerticalStrut(5));
        saveReviews();
    }
    private int getRatingFromUser(JDialog parent) {
        Object[] options = {1, 2, 3, 4, 5};
        Object selectedValue = JOptionPane.showInputDialog(parent, "Rate this game (1-5):", "Rating", JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        if (selectedValue != null) {
            return (int) selectedValue;
        }
        return -1;
    }
    private void addLabelAndValue(JPanel panel, GridBagConstraints gbc, int row, String labelText, String valueText) {
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel(labelText), gbc);
        gbc.gridx = 1;
        panel.add(new JLabel(valueText), gbc);
    }
    private void saveReviews() {
        try (PrintWriter writer = new PrintWriter("reviews.dat")) {
            for (List<Review> reviews : gameReviews.values()) {
                for (Review review : reviews) {
                    writer.println(String.format("%d,%d,%s,%s,%d",
                            review.getId(), review.getGameId(), review.getUsername(), review.getComment(), review.getRating()));
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving reviews.");
        }
    }
    private void loadReviews() {
        gameReviews.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader("reviews.dat"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 5) {
                    int id = Integer.parseInt(parts[0]);
                    int gameId = Integer.parseInt(parts[1]);
                    String username = parts[2];
                    String comment = parts[3];
                    int rating = Integer.parseInt(parts[4]);

                    Review review = new Review(username, comment, rating, gameId);
                    review.setId(id);
                    gameReviews.computeIfAbsent(gameId, k -> new ArrayList<>()).add(review);

                    if (Review.nextId <= id) {
                        Review.nextId = id + 1;
                    }
                }
            }
        } catch (FileNotFoundException e) {
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading reviews.");
        }
    }
    private void updateMarketDataFile(Node updatedNode) {
        try {
            List<String> updatedLines = new ArrayList<>();
            for (String line : lines) {
                String[] parts = line.split(",");
                if (parts.length >= 6 && Integer.parseInt(parts[0]) == updatedNode.gameId) {
                    updatedLines.add(updatedNode.toStringForFile(genres));
                } else {
                    updatedLines.add(line);
                }
            }
            try (PrintWriter writer = new PrintWriter("Market.dat")) {
                for (String line : updatedLines) {
                    writer.println(line);
                }
            }
            lines = updatedLines;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating Market.dat: " + e.getMessage());
            e.printStackTrace();
        }
    }
    private void updateCartDisplay() {
        cartListModel.clear();
        for (Node game : shoppingCart.getItems()) {
            cartListModel.addElement(game.toString());
        }

    }
    private void checkout() {
        if (shoppingCart.getItems().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Your cart is empty!");
            return;
        }

        double totalPrice = shoppingCart.getTotalPrice();

        int confirm = JOptionPane.showConfirmDialog(this,
                String.format("Total price: $%.2f\nConfirm purchase?", totalPrice),
                "Confirm Checkout",
                JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            for (Node game : shoppingCart.getItems()) {
                if (game.stock > 0) {
                    game.stock--;
                    gamesSold.put(game.gameId, gamesSold.getOrDefault(game.gameId, 0) + 1);
                    updateMarketDataFile(game);

                    currentUser.getOrderHistory().add(game);
                    saveUserOrderHistory(currentUser);
                } else {
                    JOptionPane.showMessageDialog(this, game.name + " is out of stock!");
                    shoppingCart.removeItem(game);
                }
            }

            JOptionPane.showMessageDialog(this, "Purchase completed!");
            shoppingCart.getItems().clear();
            updateCartDisplay();
            saveUserData();
        }
    }

    private int getQuantityFromUser() {
        try {
            String input = JOptionPane.showInputDialog(this, "Enter the number of cheapest games to purchase:");
            if (input == null) {
                return -1;
            }
            return Integer.parseInt(input);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter a number.");
            return -1;
        }
    }

    private void deleteGame(int gameId) {
        Node deletedNode = gameMap.remove(gameId);
        if (deletedNode != null) {
            genreTrees.get(deletedNode.genreId).delete(deletedNode);
            hashTable.delete(deletedNode.name);
            genreHeaps.get(deletedNode.genreId).remove(deletedNode);
            minHeap.remove(deletedNode);
        }
        try (PrintWriter writer = new PrintWriter("Market.dat")) {
            for (Node node : gameMap.values()) {
                writer.println(node.toStringForFile(genres));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error updating Market.dat: " + e.getMessage());
            e.printStackTrace();
        }

        gameReviews.remove(gameId);
        saveReviews();
        refreshGameList();
        displayLoadedData();

        JOptionPane.showMessageDialog(this, "Game deleted successfully!");
    }

    private void populateGameList(List<Node> nodes) {
        gameListModel.clear();
        for (Node node : nodes) {
            gameListModel.addElement(node.toString());
        }
    }
    public boolean loginUser(String username, String password) {
        User user = registeredUsers.get(username) ;
        if (user != null && user.getPasswordHash().equals(password)) {
            currentUser = user;
            shoppingCart = userCarts.computeIfAbsent(currentUser, k -> new ShoppingCart());
            JOptionPane.showMessageDialog(this, "Welcome, " + currentUser.getUsername() + "!");
            return true;
        } else {
            return false;
        }
    }
    private void loadData() {
        genreTrees = new HashMap<>();
        genreHeaps = new HashMap<>();
        hashTable = new HashTable();
        minHeap = new PriorityQueue<>(Comparator.comparingDouble(Node::getPrice));
        lines = new ArrayList<>();

        Set<Integer> validGenreIds = new HashSet<>(Arrays.asList(1, 2, 3, 4, 5, 6, 7, 8));

        try (BufferedReader reader = new BufferedReader(new FileReader("Market.dat"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lines.add(line);

                String[] elements = line.split(",");
                if (elements.length < 6) {
                    outputArea.append("Invalid data format in Market.dat: " + line + "\n");
                    continue;
                }
                try {
                    int gameId = Integer.parseInt(elements[0]);
                    String name = elements[1];
                    int genreId = Integer.parseInt(elements[2]);
                    int stock = Integer.parseInt(elements[4]);
                    double price = Double.parseDouble(elements[5]);
                    String imagePath = "";

                    if (elements.length > 6) {
                        imagePath = elements[6];
                        if (!imagePath.startsWith("images/")) {
                            outputArea.append("Invalid image path in Market.dat: " + line + "\n");
                            continue;
                        }
                    }
                    if (!validGenreIds.contains(genreId)) {
                        outputArea.append("Invalid genre ID in Market.dat: " + line + "\n");
                        continue;
                    }

                    Node node = new Node(gameId, name, genreId, stock, price, imagePath);
                    gameMap.put(gameId, node);
                    gameCosts.put(gameId, node.price);
                    genreTrees.computeIfAbsent(genreId, k -> new BST()).insert(node);
                    hashTable.insert(name, node);

                    genreHeaps.computeIfAbsent(genreId, k -> new PriorityQueue<>(Comparator.comparingDouble(Node::getPrice)))
                            .offer(node);
                    minHeap.offer(node);
                } catch (NumberFormatException e) {
                    outputArea.append("Invalid number format in Market.dat: " + line + "\n");
                }
            }
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Market.dat file not found. Please check the file path.");
            e.printStackTrace();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Market.dat: " + e.getMessage());
            e.printStackTrace();
        }
    }
    private double calculateTotalRevenue() {
        return gamesSold.entrySet().stream()
                .mapToDouble(entry -> gameMap.get(entry.getKey()).price * entry.getValue())
                .sum();
    }

    private double calculateTotalExpenses() {
        return gamesSold.entrySet().stream()
                .mapToDouble(entry -> gameCosts.get(entry.getKey()) * entry.getValue())
                .sum();
    }

    private double calculateProfit() {
        return calculateTotalRevenue() - calculateTotalExpenses();
    }

    private void displayLoadedData() {
        outputArea.setText("");
        //market dosyasını bastırıyor
        outputArea.append("Data from market.dat:\n");
        if (lines != null && !lines.isEmpty()) {
            for (String line : lines) {
                outputArea.append(line + "\n");
            }
        } else {
            outputArea.append("Market.dat is empty or could not be loaded.\n");
        }
        // inorder BST
        outputArea.append("\nBSTs (In-order Traversal):\n");
        for (int genreId : genreTrees.keySet()) {
            outputArea.append("\nGenre " + genreId + ":\n");
            genreTrees.get(genreId).inorder(outputArea);
        }

//hash table bastırıyor
        outputArea.append("\nHash Table:\n");
        for (int i = 0; i < hashTable.table.length; i++) {
            LinkedList<Node> bucket = hashTable.table[i];
            if (bucket != null && !bucket.isEmpty()) {
                outputArea.append("Index " + i + ": ");
                for (Node node : bucket) {
                    outputArea.append(node.toString() + " ");
                }
                outputArea.append("\n");
            }
        }
        outputArea.append("\nHash Table (Example Search - 'Elden Ring'):\n");//örnek bir arama koydum buraya
        List<Node> searchResults = hashTable.searchByName("Elden Ring");
        if (!searchResults.isEmpty()) {
            for (Node node : searchResults) {
                outputArea.append(node.toString() + "\n");
            }
        } else {
            outputArea.append("Game not found.\n");
        }
        outputArea.append("\nMin-Heaps (Cheapest Games by Genre):\n");
        for (int genreId : genreHeaps.keySet()) {
            PriorityQueue<Node> heap = genreHeaps.get(genreId);
            outputArea.append("\nGenre " + genreId + ":\n");
            printMinHeap(heap);
        }
    }
    private void printMinHeap(PriorityQueue<Node> minHeap) {
        if (minHeap.isEmpty()) {
            outputArea.append("Heap is empty.\n");
            return;
        }
        while (!minHeap.isEmpty()) {
            outputArea.append(minHeap.poll().toString() + "\n");
        }
    }
    private void searchGames() {
        String searchTerm = searchField.getText().toLowerCase();
        String selectedGenre = (String) genreComboBox.getSelectedItem();
        gameListModel.clear();
        allNodes.clear();

        if (searchTerm.isEmpty() && selectedGenre.equals("All Genres")) {
            for (BST tree : genreTrees.values()) {
                addGamesToList(tree.root, allNodes);
            }
        } else {
            int genreId = selectedGenre.equals("All Genres") ? -1 : genreComboBox.getSelectedIndex(); // Corrected genreId
            if (!searchTerm.isEmpty()) {
                List<Node> nodes = hashTable.searchByName(searchTerm);

                if (genreId != -1) {
                    nodes.removeIf(node -> node.genreId != genreId + 1);
                }

                allNodes.addAll(nodes);
            } else {
                if (genreId != -1) {
                    BST genreTree = genreTrees.get(genreId);
                    if (genreTree != null) {
                        addGamesToList(genreTree.root, allNodes);
                    } else {
                        gameListModel.addElement("No games found for the selected genre.");
                        return;
                    }
                }
            }
        }
        allNodes.sort(Comparator.comparingDouble(Node::getPrice));

        for (Node node : allNodes) {
            gameListModel.addElement(node.toString());
        }

        if (gameListModel.isEmpty()) {
            gameListModel.addElement("No games found.");
        }
    }
    private void addGamesToList(Node node) {
        if (node != null) {
            addGamesToList(node.left);
            gameListModel.addElement(node.toString());
            addGamesToList(node.right);
        }
    }
    private void addGamesToList(Node node, List<Node> nodes) {
        if (node != null) {
            addGamesToList(node.left, nodes);
            nodes.add(node);
            addGamesToList(node.right, nodes);
        }
    }
    private void refreshGameList() {
        gameListModel.clear();
        for (BST tree : genreTrees.values()) {
            addGamesToList(tree.root);
        }
    }
    private void loadUserData() {
        try (BufferedReader reader = new BufferedReader(new FileReader("registeredUsers.dat"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String username = parts[0];
                    String passwordHash = parts[1];
                    boolean isAdmin = Boolean.parseBoolean(parts[2]);
                    registeredUsers.put(username, new User(username, passwordHash, isAdmin));
                }
            }} catch (FileNotFoundException e) {
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading user data.");
        }
    }
    private void saveUserData() {
        try (PrintWriter writer = new PrintWriter("registeredUsers.dat")) {
            for (User user : registeredUsers.values()) {
                writer.println(String.format("%s,%s,%b",
                        user.getUsername(), user.getPasswordHash(), user.isAdmin()));
            }} catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error saving user data.");
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(GameMarketGUI::new);
    }
}



