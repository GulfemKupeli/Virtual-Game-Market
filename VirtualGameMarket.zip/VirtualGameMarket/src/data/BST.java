package data;

import javax.swing.*;

public class BST {
    public Node root;


    public void insert(Node node) {
        root = insertRec(root, node);
    }

    private Node insertRec(Node root, Node node) {
        if (root == null) {
            return node;
        }
        if (node.name.compareTo(root.name) < 0) {
            root.left = insertRec(root.left, node);
        } else if (node.name.compareTo(root.name) > 0) {
            root.right = insertRec(root.right, node);
        } else {
            return root;
        }
        root.height = 1 + Math.max(height(root.left), height(root.right));
        int balance = getBalance(root);

        if (balance > 1 && node.name.compareTo(root.left.name) < 0)
            return rightRotate(root);
        if (balance < -1 && node.name.compareTo(root.right.name) > 0)
            return leftRotate(root);

        if (balance > 1 && node.name.compareTo(root.left.name) > 0) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }
        if (balance < -1 && node.name.compareTo(root.right.name) < 0) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }

        return root;
    }

    public Node delete(Node nodeToDelete) {
        root = deleteNode(root, nodeToDelete.gameId);
        return root;
    }
    private Node deleteNode(Node root, int gameId) {
        if (root == null) {
            return root; // Node not found
        }
        if (gameId < root.gameId) {
            root.left = deleteNode(root.left, gameId);
        } else if (gameId > root.gameId) {
            root.right = deleteNode(root.right, gameId);
        } else {//tek ya da çift çocuk olursa
            if ((root.left == null) || (root.right == null)) {
                Node temp = root.left != null ? root.left : root.right;
                if (temp == null) {
                    temp = root;
                    root = null;
                } else {
                    root = temp;
                }
            } else {
                //iki çocuklu node için . successor u buluyoruz.
                Node temp = minValueNode(root.right);
                root.gameId = temp.gameId;
                root.name = temp.name;
                root.genreId = temp.genreId;
                root.stock = temp.stock;
                root.price = temp.price;
                root.imagePath = temp.imagePath;
                root.right = deleteNode(root.right, temp.gameId);
            }
        }

        if (root == null)
            return root;

        root.height = Math.max(height(root.left), height(root.right)) + 1;
        int balance = getBalance(root);

        if (balance > 1 && getBalance(root.left) >= 0)
            return rightRotate(root);

        if (balance > 1 && getBalance(root.left) < 0) {
            root.left = leftRotate(root.left);
            return rightRotate(root);
        }
        if (balance < -1 && getBalance(root.right) <= 0)
            return leftRotate(root);

        if (balance < -1 && getBalance(root.right) > 0) {
            root.right = rightRotate(root.right);
            return leftRotate(root);
        }

        return root;
    }

    // BST deki minimum değeri bulan metot
    private Node minValueNode(Node node) {
        Node current = node;
        while (current.left != null)
            current = current.left;
        return current;
    }

    // minimum gameId yi buluyor
    private int findMinGameId(Node node) {
        int minVal = node.gameId;
        while (node.left != null) {
            minVal = node.left.gameId;
            node = node.left;
        }
        return minVal;
    }

    // minimum game name buluyor
    private String findMinGameName(Node node) {
        String minval = node.name;
        while (node.left != null) {
            minval = node.left.name;
            node = node.left;
        }
        return minval;
    }
    public void inorder(JTextArea outputArea) {
        inorderTraversal(root, outputArea);
    }
    private void inorderTraversal(Node node, JTextArea outputArea) {
        if (node != null) {
            inorderTraversal(node.left, outputArea);
            outputArea.append(node.toString() + "\n"); // Append to JTextArea
            inorderTraversal(node.right, outputArea);
        }
    }
    public Node searchById(int id) {
        return searchByIdHelper(root, id);
    }

    private Node searchByIdHelper(Node node, int id) {
        if (node == null || node.gameId == id) {
            return node;
        }

        if (id < node.gameId) {
            return searchByIdHelper(node.left, id);
        } else {
            return searchByIdHelper(node.right, id);
        }
    }
    private int height(Node node) {
        return node == null ? 0 : node.height;
    }

    private int getBalance(Node node) {
        return node == null ? 0 : height(node.left) - height(node.right);
    }

    private Node rightRotate(Node y) {
        Node x = y.left;
        Node T2 = x.right;

        x.right = y;
        y.left = T2;

        y.height = Math.max(height(y.left), height(y.right)) + 1;
        x.height = Math.max(height(x.left), height(x.right)) + 1;

        return x;
    }
    private Node leftRotate(Node x) {
        Node y = x.right;
        Node T2 = y.left;
        y.left = x;
        x.right = T2;
        x.height = Math.max(height(x.left), height(x.right)) + 1;
        y.height = Math.max(height(y.left), height(y.right)) + 1;

        return y;
    }
}
