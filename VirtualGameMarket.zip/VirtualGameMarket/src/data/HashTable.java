package data;

import java.util.*;

public class HashTable {
    public static final int TABLE_SIZE = 128;
    public LinkedList<Node>[] table;

    public HashTable() {
        table = new LinkedList[TABLE_SIZE];
        for (int i = 0; i < TABLE_SIZE; i++) {
            table[i] = new LinkedList<>();
        }
    }

    private int hash(String key) {
        int hash = 0;
        for (int i = 0; i < key.length(); i++) {
            hash = (hash * 31 + key.charAt(i)) % TABLE_SIZE;
        }
        return Math.abs(hash);
    }
    public void insert(String key, Node node) {
        int index = hash(key);
        table[index].add(node);
    }
    public List<Node> searchByName(String name) {
        List<Node> matchingNodes = new ArrayList<>();
        for (LinkedList<Node> bucket : table) {
            for (Node node : bucket) {
                if (node.name.toLowerCase().contains(name.toLowerCase())) {
                    matchingNodes.add(node);
                }
            }
        }
        return matchingNodes;
    }

    // genreId ye göre arama metotu
    public List<Node> searchByGenre(int genreId) {
        List<Node> matchingNodes = new ArrayList<>();
        for (LinkedList<Node> bucket : table) {
            for (Node node : bucket) {
                if (node.genreId == genreId) {
                    matchingNodes.add(node);
                }
            }
        }
        return matchingNodes;
    }
    public void delete(String key) {
        int index = hash(key);
        if (table[index] != null) {
            Iterator<Node> iterator = table[index].iterator();
            while (iterator.hasNext()) {
                Node node = iterator.next();
                if (node.name.equalsIgnoreCase(key)) {
                    iterator.remove();
                    return; // Found and deleted
                }
            }
        }
    }
    // key e göre arama
    public Node search(String key) {
        int index = hash(key);
        for (Node node : table[index]) {
            if (node.name.equals(key)) {
                return node;
            }
        }
        return null;
    }
    public void remove(String name, int gameId) {
        int index = hashFunction(name);
        LinkedList<Node> bucket = table[index];
        if (bucket != null) {
            bucket.removeIf(node -> node.name.equals(name) && node.gameId == gameId);
        }
    }
    private int hashFunction(String name) {
        int hash = 0;
        for (int i = 0; i < name.length(); i++) {
            hash = (hash * 31 + name.charAt(i)) % table.length; // Simple hash function for demonstration
        }
        return hash;
    }

}
