package data;

public class Node implements Comparable<Node> {
    public int gameId;
    public String name;
    public int genreId;
    public int stock;
    public double price;
    public Node left, right;
    public String imagePath;
    public int height;
    public double getPrice() {
        return price;
    }

    public Node(int gameId, String name, int genreId, int stock, double price, String imagePath) {
        this.gameId = gameId;
        this.name = name;
        this.genreId = genreId;
        this.stock = stock;
        this.price = price;
        this.imagePath = imagePath;
    }

    @Override
    public int compareTo(Node other) {
        return Double.compare(this.price, other.price);
    }

    public String toStringForFile(String[] genres) {
        return String.format("%d,%s,%d,%s,%d,%.2f,%s",
                gameId, name, genreId, genres[genreId - 1], stock, price, imagePath);
    }
    @Override
    public String toString() {
        return gameId + "," + name + "," + genreId + "," + stock + "," + price;
    }
}

