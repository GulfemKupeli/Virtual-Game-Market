package views;

import model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.UUID;
import main.GameMarketGUI;

public class UserRegistrationDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JCheckBox isAdminCheckbox;

    public UserRegistrationDialog(JFrame parent) {
        super(parent, "User Registration", true);

        JPanel panel = new JPanel(new GridLayout(4, 2));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField(20);
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField(20);
        panel.add(passwordField);

        panel.add(new JLabel("Is Admin?"));
        isAdminCheckbox = new JCheckBox();
        panel.add(isAdminCheckbox);

        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                boolean isAdmin = isAdminCheckbox.isSelected();

                if (isValidInput(username, password)) {
                    String hashedPassword = UUID.nameUUIDFromBytes(password.getBytes()).toString();
                    User newUser = new User(username, hashedPassword, isAdmin);

                    GameMarketGUI parentGUI = (GameMarketGUI) parent;
                    if (parentGUI.registerUser(newUser)) {
                        JOptionPane.showMessageDialog(UserRegistrationDialog.this, "Registration successful!");
                        dispose();
                    } else {
                        JOptionPane.showMessageDialog(UserRegistrationDialog.this, "Username already exists.");
                    }
                } else {
                    JOptionPane.showMessageDialog(UserRegistrationDialog.this, "Invalid input. Please check your details.");
                }
            }
        });

        panel.add(registerButton);
        add(panel);
        pack();
        setLocationRelativeTo(parent);
    }

    private boolean isValidInput(String username, String password) {
        return true;
    }
}

