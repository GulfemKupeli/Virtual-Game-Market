package views;

import data.Node;
import main.GameMarketGUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AddGameDialog extends JDialog {
    private JTextField gameIdField = new JTextField();
    private JTextField nameField = new JTextField();
    private JComboBox<String> genreComboBox;
    private JTextField stockField = new JTextField();
    private JTextField priceField = new JTextField();
    private JTextField imagePathField = new JTextField();

    public AddGameDialog(GameMarketGUI parent) {
        super(parent, "Add New Game", true);

        String[] genres = {"RPG", "Sports/Racing", "Sandbox & Simulation",
                "Nintendo Switch Exclusives", "Japanese RPGs (JRPGs)", "Fighting Games",
                "First-Person Shooters (FPS)", "Strategy Games"};
        genreComboBox = new JComboBox<>(genres);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        int row = 0;

        addLabelAndComponent(panel, gbc, row++, "Game ID:", gameIdField);

        addLabelAndComponent(panel, gbc, row++, "Name:", nameField);

        addLabelAndComponent(panel, gbc, row++, "Genre:", genreComboBox);
        addLabelAndComponent(panel, gbc, row++, "Stock:", stockField);

        addLabelAndComponent(panel, gbc, row++, "Price:", priceField);

        addLabelAndComponent(panel, gbc, row++, "Image Path:", imagePathField);


        JButton addButton = new JButton("Add Game");
        addButton.addActionListener(e -> {
            try {
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Please enter valid numbers for ID, stock, and price.");
            }
        });

        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        panel.add(addButton, gbc);

        add(panel);
        pack();
        setLocationRelativeTo(parent);
    }
    private void addLabelAndComponent(JPanel panel, GridBagConstraints gbc, int row, String labelText, Component component) {
        gbc.gridx = 0;
        gbc.gridy = row;
        gbc.fill = GridBagConstraints.NONE;
        panel.add(new JLabel(labelText), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        panel.add(component, gbc);
    }
}

