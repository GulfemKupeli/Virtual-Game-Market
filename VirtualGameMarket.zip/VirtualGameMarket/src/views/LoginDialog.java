package views;

import main.GameMarketGUI;
import model.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.UUID;

public class LoginDialog extends JDialog {
    private JTextField usernameField;
    private JPasswordField passwordField;

    public LoginDialog(GameMarketGUI parent) {
        super(parent, "Login", true);

        JPanel panel = new JPanel(new GridLayout(3, 2));

        panel.add(new JLabel("Username:"));
        usernameField = new JTextField(20);
        panel.add(usernameField);

        panel.add(new JLabel("Password:"));
        passwordField = new JPasswordField(20);
        panel.add(passwordField);

        JButton loginButton = new JButton("Login");
        loginButton.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());

            String hashedPassword = UUID.nameUUIDFromBytes(password.getBytes()).toString();

            if (parent.loginUser(username, hashedPassword)) {
                JOptionPane.showMessageDialog(this, "Login successful!");
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.");
            }
        });
        panel.add(loginButton);

        add(panel);
        pack();
        setLocationRelativeTo(parent);
    }
}
